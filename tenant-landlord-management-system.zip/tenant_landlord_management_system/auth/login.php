<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
if (!empty($_SESSION['user'])) { header('Location: ../'); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $stmt=$pdo->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
    $stmt->execute([trim($_POST['email'])]);
    $user=$stmt->fetch();
    if ($user && password_verify($_POST['password'],$user['password_hash'])) {
        $_SESSION['user']=['id'=>$user['id'],'name'=>$user['name'],'email'=>$user['email'],'role'=>$user['role']];
        if($user['role']==='admin') header('Location: ../admin/dashboard.php');
        elseif($user['role']==='landlord') header('Location: ../landlord/dashboard.php');
        else header('Location: ../tenant/dashboard.php');
        exit;
    }
    $error='Invalid email or password.';
}
$title='Login'; require '../includes/header.php';
?>
<div class="row justify-content-center"><div class="col-md-5">
<div class="card p-4"><h3>System Login</h3>
<?php if($error): ?><div class="alert alert-danger"><?=h($error)?></div><?php endif; ?>
<form method="post">
<label class="form-label">Email</label><input class="form-control mb-3" type="email" name="email" required>
<label class="form-label">Password</label><input class="form-control mb-3" type="password" name="password" required>
<button class="btn btn-primary w-100">Login</button>
</form>
<hr><small>Demo: admin@example.com / password</small>
</div></div></div>
<?php require '../includes/footer.php'; ?>
