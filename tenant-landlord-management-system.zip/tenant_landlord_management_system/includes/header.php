<?php require_once __DIR__.'/auth.php'; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($title ?? 'Tenant & Landlord MIS') ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="/tenant-landlord-system/assets/css/app.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
<div class="container">
<a class="navbar-brand fw-bold" href="/tenant-landlord-system/">TL-MIS</a>
<div class="ms-auto">
<?php if (!empty($_SESSION['user'])): ?>
<span class="text-white me-3"><?= h($_SESSION['user']['name']) ?> (<?= h($_SESSION['user']['role']) ?>)</span>
<a class="btn btn-light btn-sm" href="/tenant-landlord-system/auth/logout.php">Logout</a>
<?php endif; ?>
</div>
</div>
</nav>
<main class="container py-4">
