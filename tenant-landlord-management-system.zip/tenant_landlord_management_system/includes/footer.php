</main>
<footer class="border-top py-3 text-center text-muted">
Tenant & Landlord Management Information System — BBIT Undergraduate Project
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/tenant-landlord-system/assets/js/app.js"></script>
</body>
</html>
