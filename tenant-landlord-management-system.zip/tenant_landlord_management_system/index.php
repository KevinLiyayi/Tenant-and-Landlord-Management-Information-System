<?php
session_start();
if (!empty($_SESSION['user'])) {
    $role = $_SESSION['user']['role'];
    if ($role === 'admin') header('Location: admin/dashboard.php');
    elseif ($role === 'landlord') header('Location: landlord/dashboard.php');
    else header('Location: tenant/dashboard.php');
    exit;
}
$title='Home'; require 'includes/header.php';
?>
<div class="hero text-center">
<h1 class="display-5 fw-bold">Tenant & Landlord Management Information System</h1>
<p class="lead">A web-based platform for managing properties, tenants, rent, service charges, maintenance and complaints.</p>
<a class="btn btn-primary btn-lg" href="auth/login.php">Login to System</a>
</div>
<?php require 'includes/footer.php'; ?>
