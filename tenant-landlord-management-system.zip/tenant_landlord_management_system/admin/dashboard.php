<?php
require_once '../config/database.php'; require_once '../includes/auth.php'; require_role('admin');
$counts=[];
foreach(['users'=>'Users','properties'=>'Properties','units'=>'Units','rent_payments'=>'Payments','maintenance_requests'=>'Maintenance','complaints'=>'Complaints'] as $table=>$label){
    $counts[$label]=(int)$pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
}
$title='Admin Dashboard'; require '../includes/header.php';
?>
<h2>Administrator Dashboard</h2><p class="text-muted">System overview</p>
<div class="row g-3">
<?php foreach($counts as $label=>$value): ?><div class="col-md-4"><div class="card p-4"><div class="text-muted"><?=h($label)?></div><div class="stat"><?=h($value)?></div></div></div><?php endforeach; ?>
</div>
<div class="card p-4 mt-4">
<h5>Quick Links</h5>
<a class="btn btn-outline-primary me-2" href="../landlord/properties.php">Properties</a>
<a class="btn btn-outline-primary" href="../landlord/payments.php">Payments</a>
</div>
<?php require '../includes/footer.php'; ?>
