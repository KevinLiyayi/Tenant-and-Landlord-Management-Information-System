# Tenant & Landlord Management Information System

A BBIT undergraduate project: **Development of a Web-Based Tenant and Landlord Management Information System**.

## Technology
- PHP 8+
- MySQL 8+
- HTML5/CSS3
- Bootstrap 5 via CDN
- JavaScript
- XAMPP
- Git/GitHub

## Main Features
- Role-based authentication: Administrator, Landlord, Tenant
- Property and rental-unit management
- Tenant management
- Rent payment recording and balance tracking
- Service-charge records
- Maintenance requests
- Complaint management
- Dashboard statistics
- Notifications/status tracking
- MySQL database

## Installation
1. Install XAMPP and start Apache + MySQL.
2. Copy this folder into `C:/xampp/htdocs/tenant-landlord-system`.
3. Open phpMyAdmin and create/import the database using `database/schema.sql`.
4. Check `config/database.php` and update credentials if necessary.
5. Open `http://localhost/tenant-landlord-system/`.
6. Default demo accounts:
   - Admin: `admin@example.com` / `password`
   - Landlord: `landlord@example.com` / `password`
   - Tenant: `tenant@example.com` / `password`

> Change demo passwords before any real deployment.

## GitHub
```bash
git init
git add .
git commit -m "Initial tenant landlord management system"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/tenant-landlord-management-system.git
git push -u origin main
```

## Academic Note
This repository is a student project prototype. Do not use real tenant identification or financial information in a public repository.
