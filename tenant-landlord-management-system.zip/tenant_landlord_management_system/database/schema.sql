CREATE DATABASE IF NOT EXISTS tenant_landlord_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tenant_landlord_db;

CREATE TABLE users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('admin','landlord','tenant') NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE properties (
 id INT AUTO_INCREMENT PRIMARY KEY,
 landlord_id INT NOT NULL,
 name VARCHAR(150) NOT NULL,
 location VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (landlord_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE units (
 id INT AUTO_INCREMENT PRIMARY KEY,
 property_id INT NOT NULL,
 unit_number VARCHAR(50) NOT NULL,
 monthly_rent DECIMAL(12,2) DEFAULT 0,
 status ENUM('vacant','occupied','maintenance') DEFAULT 'vacant',
 FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE
);

CREATE TABLE tenants (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNIQUE NULL,
 unit_id INT NOT NULL,
 name VARCHAR(120) NOT NULL,
 phone VARCHAR(30),
 national_id VARCHAR(50),
 lease_start DATE NULL,
 lease_end DATE NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
 FOREIGN KEY (unit_id) REFERENCES units(id) ON DELETE RESTRICT
);

CREATE TABLE rent_payments (
 id INT AUTO_INCREMENT PRIMARY KEY,
 tenant_id INT NOT NULL,
 amount DECIMAL(12,2) NOT NULL,
 payment_date DATE NOT NULL,
 reference VARCHAR(100),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

CREATE TABLE service_charges (
 id INT AUTO_INCREMENT PRIMARY KEY,
 tenant_id INT NOT NULL,
 description VARCHAR(255) NOT NULL,
 amount DECIMAL(12,2) NOT NULL,
 due_date DATE,
 status ENUM('pending','paid') DEFAULT 'pending',
 FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

CREATE TABLE maintenance_requests (
 id INT AUTO_INCREMENT PRIMARY KEY,
 tenant_id INT NOT NULL,
 description TEXT NOT NULL,
 priority ENUM('low','medium','high') DEFAULT 'medium',
 status ENUM('open','in_progress','resolved') DEFAULT 'open',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

CREATE TABLE complaints (
 id INT AUTO_INCREMENT PRIMARY KEY,
 tenant_id INT NOT NULL,
 description TEXT NOT NULL,
 status ENUM('open','in_progress','resolved') DEFAULT 'open',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
);

CREATE TABLE notifications (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 title VARCHAR(150) NOT NULL,
 message TEXT NOT NULL,
 is_read TINYINT(1) DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE messages (
 id INT AUTO_INCREMENT PRIMARY KEY,
 sender_id INT NOT NULL,
 receiver_id INT NOT NULL,
 message TEXT NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Demo password for all accounts is: password
INSERT INTO users(name,email,password_hash,role) VALUES
('System Administrator','admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC2b5y8n0x4pZQpZ9a6G', 'admin'),
('Demo Landlord','landlord@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC2b5y8n0x4pZQpZ9a6G', 'landlord'),
('Demo Tenant','tenant@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC2b5y8n0x4pZQpZ9a6G', 'tenant');

INSERT INTO properties(landlord_id,name,location) VALUES (2,'Sunrise Apartments','Nakuru, Kenya');
INSERT INTO units(property_id,unit_number,monthly_rent,status) VALUES (1,'A-01',15000,'occupied'),(1,'A-02',15000,'vacant');
INSERT INTO tenants(user_id,unit_id,name,phone,national_id,lease_start) VALUES (3,1,'Demo Tenant','0700000000','DEMO-001',CURDATE());
INSERT INTO rent_payments(tenant_id,amount,payment_date,reference) VALUES (1,15000,CURDATE(),'DEMO-RENT-001');
