<?php
require_once '../config/database.php'; require_once '../includes/auth.php'; require_role('landlord');
$uid=$_SESSION['user']['id'];
$propertyCount=$pdo->prepare("SELECT COUNT(*) FROM properties WHERE landlord_id=?");$propertyCount->execute([$uid]);
$tenantCount=$pdo->prepare("SELECT COUNT(*) FROM tenants t JOIN units u ON t.unit_id=u.id JOIN properties p ON u.property_id=p.id WHERE p.landlord_id=?");$tenantCount->execute([$uid]);
$payments=$pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM rent_payments rp JOIN tenants t ON rp.tenant_id=t.id JOIN units u ON t.unit_id=u.id JOIN properties p ON u.property_id=p.id WHERE p.landlord_id=?");$payments->execute([$uid]);
$title='Landlord Dashboard'; require '../includes/header.php';
?>
<h2>Landlord Dashboard</h2><div class="row g-3 mt-1">
<div class="col-md-4"><div class="card p-4"><div class="text-muted">Properties</div><div class="stat"><?=h($propertyCount->fetchColumn())?></div></div></div>
<div class="col-md-4"><div class="card p-4"><div class="text-muted">Tenants</div><div class="stat"><?=h($tenantCount->fetchColumn())?></div></div></div>
<div class="col-md-4"><div class="card p-4"><div class="text-muted">Rent Collected</div><div class="stat">KES <?=number_format($payments->fetchColumn(),2)?></div></div></div>
</div>
<div class="card p-4 mt-4">
<a class="btn btn-primary me-2" href="properties.php">Manage Properties</a>
<a class="btn btn-outline-primary me-2" href="payments.php">Record Payment</a>
<a class="btn btn-outline-primary" href="requests.php">Requests & Complaints</a>
</div>
<?php require '../includes/footer.php'; ?>
