<?php
require_once '../config/database.php'; require_once '../includes/auth.php'; require_role('landlord');
$uid=$_SESSION['user']['id']; $msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $name=trim($_POST['name']);$location=trim($_POST['location']);$units=(int)$_POST['units'];
    $pdo->beginTransaction();
    $s=$pdo->prepare("INSERT INTO properties(landlord_id,name,location) VALUES(?,?,?)");$s->execute([$uid,$name,$location]);$pid=$pdo->lastInsertId();
    $u=$pdo->prepare("INSERT INTO units(property_id,unit_number,monthly_rent,status) VALUES(?,?,?,'vacant')");
    for($i=1;$i<=$units;$i++) $u->execute([$pid,'Unit-'.$i,0]);
    $pdo->commit();$msg='Property added successfully.';
}
$s=$pdo->prepare("SELECT p.*,COUNT(u.id) unit_count FROM properties p LEFT JOIN units u ON p.id=u.property_id WHERE p.landlord_id=? GROUP BY p.id ORDER BY p.id DESC");$s->execute([$uid]);$properties=$s->fetchAll();
$title='Properties';require '../includes/header.php';
?>
<h2>Property Management</h2><?php if($msg):?><div class="alert alert-success"><?=h($msg)?></div><?php endif;?>
<div class="card p-4 mb-4"><h5>Add Property</h5><form method="post" class="row g-2">
<div class="col-md-5"><input class="form-control" name="name" placeholder="Property name" required></div>
<div class="col-md-4"><input class="form-control" name="location" placeholder="Location" required></div>
<div class="col-md-2"><input class="form-control" type="number" min="1" name="units" placeholder="Units" required></div>
<div class="col-md-1"><button class="btn btn-primary">Add</button></div></form></div>
<div class="card p-4"><table class="table"><thead><tr><th>Property</th><th>Location</th><th>Units</th></tr></thead><tbody>
<?php foreach($properties as $p):?><tr><td><?=h($p['name'])?></td><td><?=h($p['location'])?></td><td><?=h($p['unit_count'])?></td></tr><?php endforeach;?>
</tbody></table></div>
<?php require '../includes/footer.php'; ?>
