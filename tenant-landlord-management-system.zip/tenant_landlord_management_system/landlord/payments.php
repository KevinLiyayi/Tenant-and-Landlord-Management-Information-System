<?php
require_once '../config/database.php'; require_once '../includes/auth.php'; require_role('landlord');
$uid=$_SESSION['user']['id'];$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $tenant=(int)$_POST['tenant_id'];$amount=(float)$_POST['amount'];$date=$_POST['payment_date'];$ref=trim($_POST['reference']);
    $check=$pdo->prepare("SELECT t.id FROM tenants t JOIN units u ON t.unit_id=u.id JOIN properties p ON u.property_id=p.id WHERE t.id=? AND p.landlord_id=?");
    $check->execute([$tenant,$uid]);
    if($check->fetch()){ $pdo->prepare("INSERT INTO rent_payments(tenant_id,amount,payment_date,reference) VALUES(?,?,?,?)")->execute([$tenant,$amount,$date,$ref]);$msg='Payment recorded.'; }
}
$s=$pdo->prepare("SELECT t.id,t.name,u.unit_number,p.name property_name FROM tenants t JOIN units u ON t.unit_id=u.id JOIN properties p ON u.property_id=p.id WHERE p.landlord_id=? ORDER BY t.name");$s->execute([$uid]);$tenants=$s->fetchAll();
$p=$pdo->prepare("SELECT rp.*,t.name tenant_name FROM rent_payments rp JOIN tenants t ON rp.tenant_id=t.id JOIN units u ON t.unit_id=u.id JOIN properties pr ON u.property_id=pr.id WHERE pr.landlord_id=? ORDER BY rp.payment_date DESC");$p->execute([$uid]);$payments=$p->fetchAll();
$title='Rent Payments';require '../includes/header.php';
?>
<h2>Rent Payments</h2><?php if($msg):?><div class="alert alert-success"><?=h($msg)?></div><?php endif;?>
<div class="card p-4 mb-4"><form method="post" class="row g-2">
<div class="col-md-4"><select class="form-select" name="tenant_id" required><option value="">Select tenant</option><?php foreach($tenants as $t):?><option value="<?=$t['id']?>"><?=h($t['name'].' - '.$t['property_name'].' / '.$t['unit_number'])?></option><?php endforeach;?></select></div>
<div class="col-md-2"><input class="form-control" name="amount" type="number" step="0.01" placeholder="Amount" required></div>
<div class="col-md-2"><input class="form-control" name="payment_date" type="date" value="<?=date('Y-m-d')?>" required></div>
<div class="col-md-3"><input class="form-control" name="reference" placeholder="Payment reference"></div>
<div class="col-md-1"><button class="btn btn-primary">Save</button></div></form></div>
<div class="card p-4"><table class="table"><thead><tr><th>Date</th><th>Tenant</th><th>Amount</th><th>Reference</th></tr></thead><tbody>
<?php foreach($payments as $p):?><tr><td><?=h($p['payment_date'])?></td><td><?=h($p['tenant_name'])?></td><td>KES <?=number_format($p['amount'],2)?></td><td><?=h($p['reference'])?></td></tr><?php endforeach;?>
</tbody></table></div>
<?php require '../includes/footer.php'; ?>
