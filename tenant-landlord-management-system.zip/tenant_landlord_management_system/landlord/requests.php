<?php
require_once '../config/database.php'; require_once '../includes/auth.php'; require_role('landlord');
$uid=$_SESSION['user']['id'];
if(isset($_GET['type']) && isset($_GET['id'])){
 $type=$_GET['type'];$id=(int)$_GET['id'];
 if(in_array($type,['maintenance','complaint'],true)){
  $table=$type==='maintenance'?'maintenance_requests':'complaints';
  $stmt=$pdo->prepare("UPDATE $table SET status='resolved' WHERE id=? AND tenant_id IN (SELECT t.id FROM tenants t JOIN units u ON t.unit_id=u.id JOIN properties p ON u.property_id=p.id WHERE p.landlord_id=?)");
  $stmt->execute([$id,$uid]);
 }
}
$m=$pdo->prepare("SELECT m.*,t.name tenant_name FROM maintenance_requests m JOIN tenants t ON m.tenant_id=t.id JOIN units u ON t.unit_id=u.id JOIN properties p ON u.property_id=p.id WHERE p.landlord_id=? ORDER BY m.id DESC");$m->execute([$uid]);
$c=$pdo->prepare("SELECT c.*,t.name tenant_name FROM complaints c JOIN tenants t ON c.tenant_id=t.id JOIN units u ON t.unit_id=u.id JOIN properties p ON u.property_id=p.id WHERE p.landlord_id=? ORDER BY c.id DESC");$c->execute([$uid]);
$title='Requests';require '../includes/header.php';
?>
<h2>Maintenance & Complaints</h2>
<div class="card p-4 mb-4"><h5>Maintenance Requests</h5><table class="table"><thead><tr><th>Tenant</th><th>Issue</th><th>Priority</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach($m as $r):?><tr><td><?=h($r['tenant_name'])?></td><td><?=h($r['description'])?></td><td><?=h($r['priority'])?></td><td><?=h($r['status'])?></td><td><?php if($r['status']!=='resolved'):?><a class="btn btn-sm btn-success" href="?type=maintenance&id=<?=$r['id']?>">Resolve</a><?php endif;?></td></tr><?php endforeach;?>
</tbody></table></div>
<div class="card p-4"><h5>Complaints</h5><table class="table"><thead><tr><th>Tenant</th><th>Complaint</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach($c as $r):?><tr><td><?=h($r['tenant_name'])?></td><td><?=h($r['description'])?></td><td><?=h($r['status'])?></td><td><?php if($r['status']!=='resolved'):?><a class="btn btn-sm btn-success" href="?type=complaint&id=<?=$r['id']?>">Resolve</a><?php endif;?></td></tr><?php endforeach;?>
</tbody></table></div>
<?php require '../includes/footer.php'; ?>
