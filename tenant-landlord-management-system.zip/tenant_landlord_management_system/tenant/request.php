<?php
require_once '../config/database.php'; require_once '../includes/auth.php'; require_role('tenant');
$uid=$_SESSION['user']['id'];$s=$pdo->prepare("SELECT id FROM tenants WHERE user_id=?");$s->execute([$uid]);$tenant=$s->fetch();$msg='';
if($_SERVER['REQUEST_METHOD']==='POST' && $tenant){
 $type=$_POST['type'];$desc=trim($_POST['description']);$priority=$_POST['priority'];
 if($type==='maintenance') $pdo->prepare("INSERT INTO maintenance_requests(tenant_id,description,priority) VALUES(?,?,?)")->execute([$tenant['id'],$desc,$priority]);
 else $pdo->prepare("INSERT INTO complaints(tenant_id,description) VALUES(?,?)")->execute([$tenant['id'],$desc]);
 $msg='Your submission has been received.';
}
$title='Submit Request';require '../includes/header.php';
?>
<h2>Submit Maintenance Request or Complaint</h2><?php if($msg):?><div class="alert alert-success"><?=h($msg)?></div><?php endif;?>
<div class="card p-4"><form method="post"><label class="form-label">Type</label><select class="form-select mb-3" name="type"><option value="maintenance">Maintenance Request</option><option value="complaint">Complaint</option></select>
<label class="form-label">Description</label><textarea class="form-control mb-3" name="description" rows="5" required></textarea>
<label class="form-label">Priority</label><select class="form-select mb-3" name="priority"><option>low</option><option selected>medium</option><option>high</option></select>
<button class="btn btn-primary">Submit</button></form></div>
<?php require '../includes/footer.php'; ?>
