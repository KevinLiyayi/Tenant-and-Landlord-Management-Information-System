<?php
require_once '../config/database.php'; require_once '../includes/auth.php'; require_role('tenant');
$uid=$_SESSION['user']['id'];
$s=$pdo->prepare("SELECT t.*,u.unit_number,u.monthly_rent,p.name property_name,p.location FROM tenants t JOIN units u ON t.unit_id=u.id JOIN properties p ON u.property_id=p.id WHERE t.user_id=?");$s->execute([$uid]);$tenant=$s->fetch();
$paid=$pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM rent_payments WHERE tenant_id=?");$paid->execute([$tenant['id']]);$paid=$paid->fetchColumn();
$title='Tenant Dashboard';require '../includes/header.php';
?>
<h2>Tenant Dashboard</h2>
<?php if(!$tenant):?><div class="alert alert-warning">Your tenant profile has not been linked yet.</div>
<?php else:?>
<div class="row g-3"><div class="col-md-4"><div class="card p-4"><div class="text-muted">Property</div><h5><?=h($tenant['property_name'])?></h5><small><?=h($tenant['location'])?> / <?=h($tenant['unit_number'])?></small></div></div>
<div class="col-md-4"><div class="card p-4"><div class="text-muted">Monthly Rent</div><div class="stat">KES <?=number_format($tenant['monthly_rent'],2)?></div></div></div>
<div class="col-md-4"><div class="card p-4"><div class="text-muted">Recorded Payments</div><div class="stat">KES <?=number_format($paid,2)?></div></div></div></div>
<div class="card p-4 mt-4"><a class="btn btn-primary me-2" href="request.php">Submit Request/Complaint</a><a class="btn btn-outline-primary" href="payments.php">Payment History</a></div>
<?php endif;?>
<?php require '../includes/footer.php'; ?>
