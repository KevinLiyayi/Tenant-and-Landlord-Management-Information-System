<?php
require_once '../config/database.php'; require_once '../includes/auth.php'; require_role('tenant');
$uid=$_SESSION['user']['id'];$s=$pdo->prepare("SELECT t.id,t.name,u.monthly_rent FROM tenants t JOIN units u ON t.unit_id=u.id WHERE t.user_id=?");$s->execute([$uid]);$t=$s->fetch();
$p=$pdo->prepare("SELECT * FROM rent_payments WHERE tenant_id=? ORDER BY payment_date DESC");$p->execute([$t['id']]);$payments=$p->fetchAll();
$title='Payment History';require '../includes/header.php';
?>
<h2>Payment History</h2><div class="card p-4"><table class="table"><thead><tr><th>Date</th><th>Amount</th><th>Reference</th></tr></thead><tbody>
<?php foreach($payments as $r):?><tr><td><?=h($r['payment_date'])?></td><td>KES <?=number_format($r['amount'],2)?></td><td><?=h($r['reference'])?></td></tr><?php endforeach;?>
</tbody></table></div>
<?php require '../includes/footer.php'; ?>
